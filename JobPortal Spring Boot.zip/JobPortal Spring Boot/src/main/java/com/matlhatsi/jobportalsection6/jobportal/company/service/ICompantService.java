package com.matlhatsi.jobportalsection6.jobportal.company.service;

import com.matlhatsi.jobportalsection6.jobportal.dto.CompanyDto;

import java.util.List;

public interface ICompantService {

    List<CompanyDto> getAllCompanies();
}
