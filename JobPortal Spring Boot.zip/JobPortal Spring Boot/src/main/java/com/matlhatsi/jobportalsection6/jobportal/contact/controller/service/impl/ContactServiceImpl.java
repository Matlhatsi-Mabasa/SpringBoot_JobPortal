package com.matlhatsi.jobportalsection6.jobportal.contact.controller.service.impl;

import com.matlhatsi.jobportalsection6.jobportal.contact.controller.service.IContactService;
import com.matlhatsi.jobportalsection6.jobportal.dto.ContactRequestDto;
import com.matlhatsi.jobportalsection6.jobportal.entity.ContactS;
import com.matlhatsi.jobportalsection6.jobportal.repo.ContactsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class ContactServiceImpl implements IContactService {

    private final ContactsRepository contactRepository;

    @Override
    public boolean saveContact(ContactRequestDto contactRequestDto) {
        boolean result = false;
        ContactS contact = contactRepository.save(transformToEntity(contactRequestDto));
        if(contact != null && contact.getId() != null) {
            result = true;
        }
        return result;
    }

    private ContactS transformToEntity(ContactRequestDto contactRequestDto) {
        ContactS contact = new ContactS();
        BeanUtils.copyProperties(contactRequestDto, contact);
        contact.setCreatedAt(Instant.now());
        contact.setCreatedBy("System");
        contact.setStatus("NEW");
        return contact;
    }
}