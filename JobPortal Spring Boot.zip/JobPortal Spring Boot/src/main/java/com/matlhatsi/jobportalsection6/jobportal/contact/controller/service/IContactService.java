package com.matlhatsi.jobportalsection6.jobportal.contact.controller.service;

import com.matlhatsi.jobportalsection6.jobportal.dto.ContactRequestDto;

public interface IContactService {

    boolean saveContact(ContactRequestDto contactRequestDto);

}
