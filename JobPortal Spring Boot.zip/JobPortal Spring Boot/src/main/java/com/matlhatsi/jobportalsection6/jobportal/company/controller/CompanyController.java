package com.matlhatsi.jobportalsection6.jobportal.company.controller;

import com.matlhatsi.jobportalsection6.jobportal.dto.CompanyDto;
import com.matlhatsi.jobportalsection6.jobportal.company.service.ICompantService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/companies")
@RequiredArgsConstructor
//@CrossOrigin(origins = {"http://localhost:5173"})
public class CompanyController {


    private final ICompantService companyService;

//    @Autowired
//    public CompanyController(ICompantService compantService) {
//    this.compantService = compantService;
//    }


    @GetMapping(version = "1.0")
    public ResponseEntity<List<CompanyDto>> getAllCompanies() {
        List<CompanyDto>companyList = companyService.getAllCompanies();
        return ResponseEntity.ok().body(companyList);
    }

}
