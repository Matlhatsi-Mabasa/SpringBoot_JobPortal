package com.matlhatsi.jobportalsection6.jobportal.repo;

import com.matlhatsi.jobportalsection6.jobportal.entity.ContactS;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactsRepository extends JpaRepository<ContactS, Long> {
}