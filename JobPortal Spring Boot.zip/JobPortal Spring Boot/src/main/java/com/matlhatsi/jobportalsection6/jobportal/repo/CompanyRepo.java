package com.matlhatsi.jobportalsection6.jobportal.repo;

import com.matlhatsi.jobportalsection6.jobportal.entity.Company;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyRepo extends JpaRepository<Company, Long> {

}
