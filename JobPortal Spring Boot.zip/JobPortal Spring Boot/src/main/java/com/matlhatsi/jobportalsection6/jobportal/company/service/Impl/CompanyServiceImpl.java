package com.matlhatsi.jobportalsection6.jobportal.company.service.Impl;

import com.matlhatsi.jobportalsection6.jobportal.company.service.ICompantService;
import com.matlhatsi.jobportalsection6.jobportal.dto.CompanyDto;
import com.matlhatsi.jobportalsection6.jobportal.entity.Company;
import com.matlhatsi.jobportalsection6.jobportal.repo.CompanyRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CompanyServiceImpl implements ICompantService {

    private final CompanyRepo companyRepository;

    @Override
    public List<CompanyDto> getAllCompanies() {
        List<Company> companyList =companyRepository.findAll();
        return companyList.stream().map(this::transformToDto).collect(Collectors.toList());
    }

    private CompanyDto transformToDto(Company company) {
        return new CompanyDto(company.getId(), company.getName(), company.getLogo(),
                company.getIndustry(), company.getSize(), company.getRating(),
                company.getLocations(), company.getFounded(), company.getDescription(),
                company.getEmployees(), company.getWebsite(), company.getCreatedAt());
    }
}
