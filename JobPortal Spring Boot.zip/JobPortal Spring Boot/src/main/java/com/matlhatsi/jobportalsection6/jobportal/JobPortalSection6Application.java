package com.matlhatsi.jobportalsection6.jobportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobPortalSection6Application {

    public static void main(String[] args) {
        SpringApplication.run(JobPortalSection6Application.class, args);
    }

}
