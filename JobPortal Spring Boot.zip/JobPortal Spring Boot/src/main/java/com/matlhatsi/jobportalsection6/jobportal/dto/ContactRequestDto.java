package com.matlhatsi.jobportalsection6.jobportal.dto;

import java.io.Serializable;

/**
 * DTO for {@link com.matlhatsi.jobportalsection6.jobportal.entity.ContactS}
 */
public record ContactRequestDto(String email, String message, String name, String subject,
                                String userType) implements Serializable {
}